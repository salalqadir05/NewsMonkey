import './App.css';
import React from 'react'
import NavBar from './Components/NavBar';
import News from './Components/News';
import {
  BrowserRouter as Router,
  Route,
  Routes
} from "react-router-dom";

const  App = ()=> {
  const apikey = process.env.REACT_APP_NEWS_API;
    return (

      <>
      <div>
    
         <Router>
            <NavBar />
            <Routes>
            <Route  exact path="/"   element={<News  apikey={ apikey} key='general' pagesize={9} category="general" />}></Route>
            <Route exact path="/business"   element={<News  apikey={ apikey}  key='business' pagesize={9} category="business" />}></Route>
            <Route exact path="/entertainment"   element={<News apikey={ apikey}   key='entertainment' pagesize={9} category="entertainment"   />}></Route>
        <Route  exact path="/health"   element={<News  apikey={ apikey} key='health' pagesize={9} category="health" />}></Route>
            <Route exact path="/science"   element={<News  apikey={ apikey}  key='science' pagesize={9} category="science" />}></Route>
            <Route exact path="/sports"   element={<News  apikey={ apikey}  key='sports'  pagesize={9} category="sports" />}></Route>
            <Route  exact path="/technology"   element={<News  apikey={ apikey} key='technology' pagesize={9} category="technology" />}></Route>
            </Routes>
      </Router>
      </div>
</>
    )
  }


  export default App
