import React from 'react'
const  Newsitem =(props)=> {
 
    let {Title,Description,ImageUrl,Url} = props;

    return (
      <div className='container my-3'>
        <div className="card" >
  <img src={!ImageUrl?"https:image.cnbcfm.com/api/v1/image/107216632-16800366682023-03-28t204752z_1360787353_rc2830atf7c7_rtrmadp_0_usa-biden.jpeg?":ImageUrl} className="card-img-top" alt="Image" />
  <div className="card-body">
    <h5 className="card-title">{Title} ...</h5>
    <p className="card-text">{Description} ...</p>
    <a href={Url} target='_blank' className="btn btn-sm btn-dark">Read Me</a>
  </div>
</div>
      </div>
    )

}

export default Newsitem
