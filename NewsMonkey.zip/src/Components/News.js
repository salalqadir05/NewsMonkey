import React, { useState,useEffect } from 'react'
import Newsitem from './Newsitem'
import Spinner from './Spinner';
import PropTypes from 'prop-types'

const News =(props)=> {

    const [articles, setarticles] = useState([]);
    const [Loading, setLoading] = useState(false);
    const [page, setpage] = useState(1);
    const [totalResults,settotalResults] = useState(0);

const update=  async () =>{
    const  url = `https://newsapi.org/v2/top-headlines?country=us&category=${props.category}&apiKey=${props.apikey}&pagesize=${props.pagesize}`;
    setLoading(true);
    let Data = await fetch(url);
    let parseData = await Data.json(); 
    setLoading(false);
    setarticles(parseData.articles);
    settotalResults(parseData.totalResults);
}

    useEffect(() => {
        update ();

    },[]);

  
 
     const   PreMove = async() =>
        {
            console.log("Previous");
           const url = `https://newsapi.org/v2/top-headlines?country=us&category=${props.category}&apiKey=${props.apikey}&page=${page - 1 }&pagesize=${props.pagesize}`;
            setLoading(true);   
            let Data = await fetch(url);
            let parseData = await Data.json(); 
            setLoading(false);
            setarticles(parseData.articles);
            setpage(page -1 );

           
        }
      const   NextMove = async() =>
        {
            if(page + 1 > Math.ceil((totalResults/ props.pagesize )))
            {}
            else
            {
            console.log("Next");

            const url = `https://newsapi.org/v2/top-headlines?country=us&category=${props.category}&apiKey=${props.apikey}&page=${page - 1 }&pagesize=${props.pagesize}`;
            setLoading(true);   
            let Data = await fetch(url);
            let parseData = await Data.json(); 
            setLoading(false);
            setarticles(parseData.articles);
            setpage(page + 1 );
        }
    }

        
        return (
            <div className='container my-3'>
                <h1 className='d-flex justify-content-center' style={{marginTop: '90px'}}>NewsMonkey - Top Headlines</h1>
                {Loading && <Spinner />}
                <div className='row my-3'>
                    {articles.map((elements) => {
                        return <div className='col-md-4' key={elements.url}>
                            <Newsitem Title={elements.title?elements.title.slice(0,40):""} Description={elements.description?elements.description.slice(0,70):""} ImageUrl={elements.urlToImage} Url={elements.url} />
                        </div>
                    })};

                </div>
                <div className='d-flex justify-content-between'>
                <button disabled={page<=1} type="button" className="btn btn-dark" onClick={PreMove}>&larr; Previous</button>
                <button disabled={page + 1 > Math.ceil((totalResults/ props.pagesize ))} type="button" className="btn btn-dark" onClick={NextMove}>Next  &rarr;</button>


                </div>
            </div>
   
    )
    
}


 News.defaultProps  ={ 
    pagesize : 9,
    category: 'general'
}
News.propsTypes = {
    pagesize : PropTypes.number,
    category : PropTypes.string
} 

export default News
